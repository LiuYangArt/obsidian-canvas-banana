
## 1. 产品概述

**目标**：在 Obsidian Canvas 视图中集成 Gemini AI (特别是 Gemini 3 Pro Image)，允许用户通过选中画布中的节点和连线构建多模态上下文，进行 AI 对话或高精度的图像生成/编辑。

**核心价值**：

- **多模态原生**：不仅仅是文生图，而是利用 Canvas 的空间结构进行“图生图”和“混合生图”。
    
- **语义链接**：利用 Canvas 的连线（Edges）作为语义桥梁，告诉 AI 图片的用途（如：风格参考、构图参考）。
    
- **极简交互**：智能预判用户意图，减少重复输入。
    

## 2. 交互与界面设计 (UI/UX)

### 2.1 核心交互：多功能悬浮面板 (The Floating Palette)

放弃模态框，采用类似 Photoshop 的**悬浮面板**，跟随鼠标或选中节点出现。

- **触发方式**：选中 Canvas 节点后，点击 "AI Sparkles ✨" 按钮。
    
- **布局**：顶部 Tab 切换模式，中间为输入区，底部为参数与操作。
    

#### 界面区域划分：

**A. 顶部模式栏 (Mode Switcher)**

- **[ 💬 Chat / Text ]**: 文本任务（总结、翻译、代码解释）。
    
- **[ 🎨 Generate Image ]**: 图像任务（生成、编辑、混合）。
    

**B. 预设与输入区 (Presets & Prompt)**

- **Prompt Input (多行文本框)**:
    
    - **智能占位符 (Smart Placeholder)**:
        
        - 默认: "Enter your prompt here..."
            
        - **[特性]** 当选区包含**文本节点**且输入框为空时: 显示 _"Leave empty to use selected text as prompt..."_ (灰色斜体)。
            
    - **输入逻辑**: 用户输入优先级 > 选中文本自动填充。
        

**C. 参数控制区 (Settings Bar)**

- 仅在生图模式显示：`Aspect Ratio` (1:1, 16:9 等), `Style` (写实, 动漫等)。
    

**D. 底部操作栏 (Action Footer)**

- **Context Preview**: 左下角显示选区摘要 "🔗 1 Group (3 images, 2 text)"。
    
- **[ Generate ] 按钮**: 执行任务。
    

### 2.2 任务反馈与异常状态

1. **加载状态**: Canvas 上生成 "Ghost Node" (占位符)，显示呼吸灯动画。
    
2. **结果回写**:
    
    - 文本任务 -> Text Node。
        
    - 图像任务 -> 保存文件至 Vault -> File Node。
        
3. **异常处理**:
    
    - **安全拦截**: Ghost Node 变为灰色 🚫 图标，点击显示 "Blocked by safety filters"。
        
    - **API 错误**: Ghost Node 变为红色 ⚠️ 图标，提供 `[Retry]` 按钮。
        

## 3. 技术实现方案 (Technical Architecture)

这是本插件的核心逻辑管线 (Pipeline)。

### 3.1 基础架构

- **本地预处理**: 不直接发送 JSONCanvas，而在本地转换为 Markdown/Mermaid/Base64。
    
- **异步队列**: 使用 `TaskQueue` 管理并发请求，不阻塞 UI 线程。
    

### 3.2 核心逻辑：智能意图解析管线 (Intelligent Intent Pipeline)

当用户点击 "Generate" 时，数据流经以下三个步骤：

#### Step 0: 选区标准化 (Pre-processing & Unwrapping)

- **输入**: 用户选中的 `selectedNodes`。
    
- **逻辑**:
    
    1. **Group 解包**: 如果选中了 Group，计算其几何范围，自动将范围内**未被选中**的子节点加入处理列表。
        
    2. **文件清洗**: 剔除非图片文件（如 PDF），剔除超大图片（或触发自动压缩）。
        
- **输出**: 扁平化的 `effectiveSelection` 列表。
    

#### Step 1: 角色解析 (Graph-based Role Assignment)

- **目标**: 确定每张图片在 Prompt 中的作用（Role）。
    
- **解析优先级**:
    
    1. **显式连线 (Labeled Edge)**: 连线指向图片且带有 Label -> `Role = Edge.Label` (e.g., "Style").
        
    2. **上游文本 (Upstream Text)**: 文本节点连线指向图片 -> `Role = TextNode.Text`.
        
    3. **分组标题 (Group Context)**: 图片在 Group 内 -> `Role = Group.Label`.
        
    4. **默认**: `Role = "Visual Reference"`.
        

#### Step 2: 指令策略 (Instruction Strategy)

- **目标**: 确定最终发给 AI 的文字指令。
    
- **判定逻辑**:
    
    1. **用户输入优先**: 如果悬浮面板输入框有内容 -> 使用输入内容。
        
    2. **自动回退**: 如果输入框为空 -> 提取 `effectiveSelection` 中**未被用作标签**的纯文本节点内容。
        
    3. **默认预设**: 如果都为空 -> 使用默认提示词 ("Summarize this" / "Generate image from refs").
        

### 3.3 布局与防呆设计 (Safety & Layout)

#### A. 智能布局 (Smart Layout)

- 计算选区包围盒 `maxX`。
    
- 新节点生成于 `x = maxX + 50`, `y = minY`。
    
- 简单的碰撞检测，若位置被占则向下偏移。
    

#### B. 防呆与边界保护 (Safety Rails)

1. **图片数量限制**: Gemini 3 限制 **14 张**。超过时自动截断并在 UI 警告。
    
2. **循环连线检测**: 遍历图谱时维护 `visited` 集合，防止死循环。
    
3. **自动压缩**: 在转 Base64 前，若图片 > 4096px，使用 OffscreenCanvas 缩小，防止 API 超时。
    
4. **空指令保护**: 若无图无字无输入，禁用 Generate 按钮。

### 3.4 难点四：基于图谱的意图解析 (Graph-based Intent Resolver)

这是本插件的核心差异化功能。我们需要将 Canvas 的**拓扑结构**翻译为 Gemini 能理解的 **语义结构**。

#### Step 0: 选区预处理与 Group 展开 (Pre-processing) **[优化点 2]**

在开始解析前，必须先标准化输入源。

1. **Group Unwrapping (自动解包)**
    
    - 遍历用户选中的 `selectedNodes`。
        
    - 如果遇到类型为 `group` 的节点：
        
        - 计算该 Group 的几何范围 (x, y, w, h)。
            
        - 扫描 Canvas 上**所有未被选中**的节点。
            
        - **包含检测**: 如果某个节点的中心点位于该 Group 范围内，将其加入 `effectiveSelection` (有效选区) 列表。
            
        - 保留 Group 节点本身（其 Label 可能作为语义 Tag），但标记为 "Container"。
            
    - 最终输出一个扁平化的 `effectiveSelection` 列表，包含所有实际需要处理的图文节点。
        

#### Step 1: 角色解析 (Role Assignment)

_(保持原逻辑：利用连线 Label > 上游文本 > Group 标题 来确定图片用途)_

#### Step 2: Prompt 提取策略 (Instruction Fallback Strategy) **[优化点 1]**

在构造最终 Payload 时，`INSTRUCTION` 字段的内容来源遵循以下**优先级回退机制**：

1. **Priority A (Explicit Input)**: 用户在悬浮面板 **输入框** 中填写的内容。
    
2. **Priority B (In-Context Text)**:
    
    - 如果输入框为空。
        
    - 检查 `effectiveSelection` 中是否有 **未被用作标签** 的文本节点。
        
    - 如果有，合并这些文本节点的内容作为指令。
        
3. **Priority C (Default Preset)**:
    
    - 如果以上皆空。
        
    - **Chat 模式**: "Summarize the selected content."
        
    - **Image 模式**: "Generate an image based on these references."
        

#### 示例场景处理 (优化后)

- **场景**: 用户在一个 Group 里放了 3 张参考图，并没有写任何 Prompt，直接选中 Group 点击 "Generate Image"。
    
- **处理流程**:
    
    1. **展开**: 插件发现选中了 Group，自动识别出内部的 3 张图片。
        
    2. **解析**: 3 张图片被作为 `image_url` 加入 Payload。
        
    3. **Prompt**: 输入框为空 -> 检查选区无文本 -> 使用默认 Prompt "Generate an image based on these references."。
        
    4. **结果**: Gemini 3 开始基于这 3 张图进行混合/变体生成。


### 3.5 难点五：智能布局与节点定位 (Layout Algorithm)

为了防止新生成的节点遮挡现有内容，需要实现简单的避让算法。

1. **计算包围盒 (Bounding Box)**:
    
    - 遍历所有选中节点，计算整体的 `minX`, `minY`, `maxX`, `maxY`。
        
2. **定位策略**:
    
    - **默认位置**: `x = maxX + 50` (右侧 50px), `y = minY` (顶部对齐)。
        
    - **尺寸预设**:
        
        - Text Node: 宽度固定 400px，高度自适应。
            
        - Image Node: 默认 500x500px (后续根据图片比例调整)。
            
3. **碰撞检测 (可选优化)**:
    
    - 检查默认位置是否已有其他节点。如果有，则向下偏移 `y += 50` 直到找到空位，或向更右侧偏移。


### 3.6 难点六：防呆设计与边界保护 (Safety Rails & Validation)

为了防止用户误操作导致 API 报错、Token 爆炸或程序崩溃，必须在 **Request 发送前** 增加一层拦截校验。

#### A. 输入校验 (Pre-flight Validation)

1. **图片数量限制 (Max Image Count)**
    
    - **规则**：Gemini 3 Pro Image 目前限制最多 **14 张** 参考图。
        
    - **动作**：如果用户选中 > 14 张图片，悬浮面板显示黄色警告："Selected images (15) exceed the limit (14). First 14 will be used."，并自动截断。
        
2. **文件大小与类型清洗 (Sanitization)**
    
    - **规则**：API 限制单张图片大小（通常 < 7MB 或 < 20MB，视 Base64 限制而定）。
        
    - **动作**：
        
        - **非图片过滤**：如果用户框选了 PDF 或 MP3，自动剔除并在 UI 提示 "Skipped non-image files"。
            
        - **自动压缩**：在转 Base64 前，检测图片分辨率。如果宽/高 > 4096px 或体积过大，在本地 Canvas 使用 OffscreenCanvas 进行 **Downscaling (缩小)** 处理，确保请求成功率。
            
3. **循环连线检测 (Loop Detection)**
    
    - **场景**：用户将文本 A 连向 文本 B，B 又连回 A。
        
    - **动作**：在 DFS/BFS 遍历构建 Context 时，维护一个 `visited` 集合。如果检测到闭环，自动中断遍历，避免死循环导致插件卡死。
        

#### B. 异常状态交互 (Error States)

1. **空指令保护**
    
    - **场景**：用户只选了图片，没写 Prompt，也没选指令文本。
        
    - **动作**：Prompt Input 框显示红色提示，或自动填充默认 Prompt："Describe these images." (Chat模式) 或 "Generate a variation." (Image模式)。
        
2. **API 密钥缺失**
    
    - **场景**：用户刚安装插件，未配置 Key 就点击生成。
        
    - **动作**：不发送请求，直接在悬浮面板弹出按钮 `[Go to Settings]`，引导用户配置。
        
3. **安全过滤器拦截 (Safety Filter Triggered)**
    
    - **场景**：Gemini 因为 NSFW 或安全原因拒绝生成。
        
    - **动作**：
        
        - 不要直接静默失败。
            
        - 生成的 Ghost Node 变为 **灰色禁止图标 🚫**。
            
        - 点击显示："Request blocked by safety filters. Please modify your prompt."
    

## 4. API Payload 设计

根据上述管线解析后的动态 JSON 结构。

```
{
  "model": "google/gemini-3-pro-image-preview",
  "messages": [
    {
      "role": "user",
      "content": [
        // System Context
        {
          "type": "text",
          "text": "You are an expert creator. Use the following references."
        },
        
        // --- 动态插入部分 (来自 Step 1 解析) ---
        // [Group 展开后] 自动提取的图片 A
        { "type": "text", "text": "\n[Ref: Group Content]" },
        { "type": "image_url", "image_url": { "url": "..." } },
        
        // [Group 展开后] 自动提取的图片 B
        { "type": "text", "text": "\n[Ref: Group Content]" },
        { "type": "image_url", "image_url": { "url": "..." } },
        
        // --- 指令部分 (来自 Step 2 策略) ---
        // 如果用户没输入，这里可能直接填充了选中卡片里的文字
        {
          "type": "text",
          "text": "\nINSTRUCTION: A cyberpunk city street..." 
        }
      ]
    }
  ]
}
```
## 5. 插件设置 (Settings)

### 5.1 API Provider 管理

- 支持多厂商 (Gemini, OpenRouter, Custom)。
    
- 字段: Name, Base URL, API Key, Model Name.
    

### 5.2 预设管理 (Prompt Presets)

- 增删改查常用 Prompt。
    

### 5.3 通用与路径

- **Image Output Path**: [ Root | Current | **Attachment** | Custom ] (默认存入附件文件夹)。
    
- **System Prompt**: 自定义全局系统提示词。
    

### 5.4 高级与安全

- **Max Reference Images**: [ Slider: 1-14 ]。
    
- **Auto-Resize Large Images**: [ Toggle: On ]。
    

---

## 6. 开发执行路线图 (Execution Plan)

1. **Phase 1: 骨架与 UI (Skeleton)**
    
    - 搭建设置页、悬浮面板 UI。
        
    - 实现这一步即可进行 UI 交互测试。
        
2. **Phase 2: 核心解析器 (The Resolver)**
    
    - 实现 `CanvasInputResolver.ts`。
        
    - 重点：**Group 解包算法**、**连线遍历逻辑**。
        
    - 测试：Console log 输出解析后的结构化数据。
        
3. **Phase 3: 视觉集成 (Vision)**
    
    - 实现图片读取 (`vault.readBinary`)、压缩、Base64 转换。
        
    - 对接 Gemini 3 API。
        
4. **Phase 4: 完善与发布 (Polish)**
    
    - 接入防呆校验。
        
    - 优化错误提示与 Ghost Node 动画。
        
    - 处理文件保存路径逻辑。