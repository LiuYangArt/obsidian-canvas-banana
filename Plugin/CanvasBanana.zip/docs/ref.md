



参考：

obsidian插件文档和示例工程

https://docs.obsidian.md/Plugins/Getting+started/Build+a+plugin

https://github.com/obsidianmd/obsidian-sample-plugin



obsidian canvas api

canvas 是json格式

https://jsoncanvas.org/

https://github.com/obsidianmd/jsoncanvas

https://forum.obsidian.md/t/any-details-on-the-canvas-api/57120/4



google gemini api文档

https://ai.google.dev/gemini-api/docs

https://ai.google.dev/gemini-api/docs/image-generationgem



open router api文档

https://openrouter.ai/google/gemini-3-pro-preview/api

https://openrouter.ai/google/gemini-3-pro-image-preview/api

https://openrouter.ai/docs/quickstart